package com.jsipac.h2SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2SpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
